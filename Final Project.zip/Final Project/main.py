from ai import call_gpt
def main():
     
    print("I am Intellex and I assist students with difficult subjects!")
    name= input("What is your name?")
    print(f"Hiiii {name}!")
    subject= input(f"Which subject is {name} having issues with?")
    topic= input(f"What's the topic would {name} loves to have more explanation and clarification?")
    explanation= call_gpt(f"provide explanations on the {topic} in the {subject}")
    print(f"{explanation}")
    answer= input(f"Do you understand better?\n"
                    "1.Yes,I understand better\n"
                    "2.I want solved examples\n"
                    "Choose 1 or 2:")
    if answer== "1":
        print("Glad, I could be of help. Have a nice day!")
    elif answer== "2":
        print("Let's solve some questions on the topic!")
        solved_questions= call_gpt(f"Provide solved questions on {topic} in the {subject}")
        print(f"{solved_questions}")
        print("Try these out yourself")
        questions=  call_gpt(f"Provide 5 questions that can be solved on the {topic} in the {subject}")
        print(f"{questions}")
        done= input("Are you done?"
               "1.Yes,I'm done\n"
               "2.No,I'm not done\n"
               "Choose 1 or 2:")
        if done== "1":
            input(f"How many did {name} get?")
        else:
            print(f"Take your time {name}!")
        print("However this is correction to the exercise!")
        correction = call_gpt(f"provide the correction to the {questions}")
        print("Wait a minute!")
        print(f"{correction}")

        
           
            

        
    



if __name__ == "__main__":
    main()